#polling/admin.py

from django.contrib import admin
from polling.models import Poll

admin.site.register(Poll)
