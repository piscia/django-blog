from django.contrib import admin

from blogging.models import Post

admin.site.register(Post)